# GMS 1.4 导入清单

文件名 = 资源名。导入时 GMS 会自动用文件名，不要改。

## 01_Sprites  →  40 个 Sprite 资源

**原点统一设置：`Origin = Custom`，`x = floor(width/2)`，`y = height`**（脚底居中）

| 角色 | 文件 | 尺寸 |
|---|---|---|
| Chip | spr_cs_chip_stand / talk | 16×24 |
| Chip | spr_cs_chip_run_0 / 1 / 2 | 20×24 / 18×25 / 18×24 |
| Chip | spr_cs_chip_shock_jump / shock_crouch | 20×24 / 23×18 |
| Chip | spr_cs_chip_wave_stand / wave_talk | 19×24 |
| Dale | spr_cs_dale_stand / talk / sleepy | 15×23 / 15×23 / 19×23 |
| Dale | spr_cs_dale_run_0 / 1 / 2 | 20×23 / 18×24 / 18×23 |
| Dale | spr_cs_dale_shock / crouch | 20×23 / 23×17 |
| Gadget | spr_cs_gadget_stand / talk | 20×26 |
| Gadget | spr_cs_gadget_walk_0 / 1 / 2 | 20×26 / 20×27 / 20×26 |
| Gadget | spr_cs_gadget_hand_stand / hand_talk | 23×26 |
| Monterey | spr_cs_monterey_stand | 31×32 |
| Monterey | spr_cs_monterey_move_0 / 1 / 2 / 3 | 31×32 / 31×32 / 31×33 / 31×32 |
| Monterey | spr_cs_monterey_point_stand / point_talk | 39×32 |
| Zipper | spr_cs_zipper_fly_0 / 1 | 16×16 / 15×16 |
| Zipper | spr_cs_zipper_look_0 / 1 | 15×16 / 16×16 |
| 其他 | spr_cs_sleep_star | 5×5 |
| 飞艇 | spr_blimp_dark_0 / 1 / lit_0 / 1 | 34×20（原点 0,0） |

**导入设置（全部 Sprite）**
- `Transparent`：**勾选**（必须，否则背景不透明）
- `Smooth edges`：**取消**
- `Preload texture`：勾选
- `Origin`：见上表

## 02_Sounds  →  8 个 Sound 资源

| 资源名 | 时长 | Kind |
|---|---|---|
| snd_chip | 0.078s | Sound Effect |
| snd_dale | 0.078s | Sound Effect |
| snd_gadget | 0.078s | Sound Effect |
| snd_monterey | 0.077s | Sound Effect |
| snd_zipper | 0.078s | Sound Effect |
| snd_newscaster | 0.078s | Sound Effect |
| snd_sfx_alarm | 0.843s | Sound Effect |
| snd_bgm_cutscene | 31.948s | **Background Music** |

**导入设置（全部 Sound）**
- `Compression`：**Uncompressed - Not Streamed**（绝对不要选 Compressed）
- `Sample rate`：44100
- `Bit depth`：16
- 只有 `snd_bgm_cutscene` 勾 `Background music`

## 03_Backgrounds  →  6 个 Background 资源

| 资源名 | 尺寸 | 用在哪 |
|---|---|---|
| bg_pano_prison | 512×176 | Part A 天空全景 |
| bg_prison_beams_0 | 256×176 | Part A 探照灯 A |
| bg_prison_beams_1 | 256×176 | Part A 探照灯 B |
| bg_fence_strip | 256×64 | Part A 铁网（循环） |
| bg_hq_room | 256×240 | Part B 房间 |
| bg_cutscene_font | 568×10 | **字体条**（71 字形 × 8px） |

**导入设置（全部 Background）**
- `Smooth edges`：**取消**
- `Preload texture`：勾选
- `Use as texture`：取消

## 导入顺序建议

1. **03_Backgrounds**（先导，因为脚本里最先用到）
2. **02_Sounds**
3. **01_Sprites**

## 导入后自检

按 F5，如果报 `Variable xxxx not set`，说明某个资源名拼错了。对照上表逐字核对。
