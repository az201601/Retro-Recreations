CHIP 'N DALE RESCUE RANGERS 2 — SPOTLIGHT REFERENCE ASSETS

This ZIP contains a 20-second, 1200-frame capture made by running the supplied ROM from a fresh reset in FCEUmm.

frames/frame_00000.png through frame_01199.png
  Individual lossless 256x240 RGB reference frames, one image per emulated frame.
  These are full-screen reference frames, not a ready-made GMS sprite animation. Do not import all 1200 as subimages; that would use excessive texture memory. We'll use selected references and build an optimized scene.

audio.wav
  Captured in-game audio, signed 16-bit stereo PCM at 48 kHz, about 19.97 seconds.

manifest.json
  Capture metadata.
